package org.vincimelun.cinemajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemajpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(CinemajpaApplication.class, args);
    }

}
