package org.vincimelun.cinema.model;

import java.util.ArrayList;
import java.util.List;

public class Film {
    private String titre;
    private float note;
    private String afficheNom;
    private String resume;
    private Personne realisateur;
    private List<Role> acteurs = new ArrayList<>();

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public float getNote() {
        return note;
    }

    public void setNote(float note) {
        this.note = note;
    }

    public String getAfficheNom() {
        return afficheNom;
    }

    public void setAfficheNom(String afficheNom) {
        this.afficheNom = afficheNom;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }

    public Personne getRealisateur() {
        return realisateur;
    }

    public void setRealisateur(Personne realisateur) {
        this.realisateur = realisateur;
    }

    public List<Role> getActeurs() {
        return acteurs;
    }

    public void setActeurs(List<Role> acteurs) {
        this.acteurs = acteurs;
    }

    public void addActeur(Role role){
        this.acteurs.add(role);
    }
}
