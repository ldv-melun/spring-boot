package org.vincimelun.cinema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemaApplicationTests {

    @Test
    void contextLoads() {
    }

}
