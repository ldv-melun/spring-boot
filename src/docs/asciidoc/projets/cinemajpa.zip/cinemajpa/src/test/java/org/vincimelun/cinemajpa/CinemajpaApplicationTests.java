package org.vincimelun.cinemajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemajpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
